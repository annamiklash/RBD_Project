CREATE TRIGGER NEWDEPTNO
    BEFORE INSERT
    ON ADEPT
declare newDeptno integer;
begin
    select max(deptno)+10 into newDeptno from adept;
    DBMS_output.put_line('Now we have ' || newDeptno|| ' departments');
  end;
/

