CREATE TRIGGER COCKTAILONMENUCOUNTER
    AFTER INSERT OR DELETE
    ON COCKTAIL_FOR_MENU
DECLARE
    cocktailCount INTEGER;
BEGIN
    SELECT count(*) INTO cocktailCount
    FROM COCKTAIL_FOR_MENU;

    DBMS_OUTPUT.PUT_LINE('Total amount of cocktails on the current menu is ' || cocktailCount);
END;
/

