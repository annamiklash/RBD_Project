CREATE TRIGGER R
    AFTER INSERT OR UPDATE
    ON AEMP
    FOR EACH ROW
begin
    DBMS_output.put_line('My trigger works');
  end;
/

