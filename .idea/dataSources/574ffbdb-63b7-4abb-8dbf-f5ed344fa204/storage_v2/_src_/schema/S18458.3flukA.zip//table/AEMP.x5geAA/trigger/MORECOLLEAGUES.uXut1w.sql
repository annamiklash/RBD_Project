CREATE TRIGGER MORECOLLEAGUES
    AFTER INSERT
    ON AEMP
    FOR EACH ROW
begin
    DBMS_output.put_line('More Colleagues');
  end;
/

