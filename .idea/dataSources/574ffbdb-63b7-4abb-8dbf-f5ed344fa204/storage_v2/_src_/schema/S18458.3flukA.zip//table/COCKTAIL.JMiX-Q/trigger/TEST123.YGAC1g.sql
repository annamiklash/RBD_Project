CREATE TRIGGER TEST123
    AFTER INSERT OR DELETE
    ON COCKTAIL
DECLARE
    coctailCount INTEGER;
BEGIN
    SELECT count(*) INTO coctailCount
    FROM cocktail;
    
    DBMS_OUTPUT.PUT_LINE('Total amount of coctails is ' || coctailCount);
END;
/

