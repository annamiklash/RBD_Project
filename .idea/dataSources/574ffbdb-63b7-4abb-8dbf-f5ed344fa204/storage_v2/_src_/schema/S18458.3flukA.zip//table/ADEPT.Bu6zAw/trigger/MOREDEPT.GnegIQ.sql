CREATE TRIGGER MOREDEPT
    AFTER INSERT
    ON ADEPT
declare numberOfDept integer;
 begin 
    select count(deptno) into numberOfDept from adept;
    DBMS_output.put_line('Now we have ' || numberOfDept|| ' departments');
  end;
/

