CREATE TRIGGER CHECK_EXP_DATE
    BEFORE INSERT
    ON LIQUOR
    FOR EACH ROW
BEGIN
    IF (:new.DATE_OF_EXP < CURRENT_DATE) THEN
        raise_application_error(-20000, 'The Product Is Expired');
    END IF;
END ;
/

