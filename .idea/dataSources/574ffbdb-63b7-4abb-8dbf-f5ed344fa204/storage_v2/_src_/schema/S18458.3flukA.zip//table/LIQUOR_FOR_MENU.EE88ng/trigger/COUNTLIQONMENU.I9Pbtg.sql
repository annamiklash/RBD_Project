CREATE TRIGGER COUNTLIQONMENU
    AFTER UPDATE OF ID_LIQUOR
    ON LIQUOR_FOR_MENU
    FOR EACH ROW
DECLARE
    liquorNameNew VARCHAR2(200);
    liquorNameOld VARCHAR2(200);

BEGIN

    SELECT name INTO liquorNameNew
    FROM liquor l
     WHERE l.ID_LIQUOR = :new.ID_LIQUOR;
    SELECT name INTO liquorNameOld
    FROM liquor l
    WHERE l.ID_LIQUOR = :old.ID_LIQUOR;

    DBMS_OUTPUT.PUT_LINE(liquorNameNew || ' has been added instead of ' || liquorNameOld);

END;
/

