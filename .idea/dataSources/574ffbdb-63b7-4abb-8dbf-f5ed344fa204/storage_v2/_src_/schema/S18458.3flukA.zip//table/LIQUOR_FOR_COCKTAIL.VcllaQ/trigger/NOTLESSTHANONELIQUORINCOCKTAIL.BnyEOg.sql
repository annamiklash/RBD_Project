CREATE TRIGGER NOTLESSTHANONELIQUORINCOCKTAIL
    BEFORE DELETE
    ON LIQUOR_FOR_COCKTAIL
    FOR EACH ROW
declare liquorCounter NUMBER;
    begin
        select INGREDIENT_COUNT into liquorCounter from COCKTAIL where COCKTAIL.ID_COCKTAIL = :OLD.ID_COCKTAIL;
        if liquorCounter = 1 THEN 
            raise_application_error(-20001, 'Cocktail must have at least one liquor');
        END IF;
    END;
/

